function setup() {
  createCanvas(600, 600);
}

function draw() {
  background(0);
  stroke('#fae');

  translate(width/2,height);
  var length;
  fractal(200);
}
function fractal(length){
  line(0,0,0,-length);
  translate(0,-length);
  if(length>1){
    push();
    rotate(PI/4);
    fractal(length*0.67);
    pop();
    push();
    rotate(-PI/4);
    fractal(length*0.67);
    pop();
  }
  
}